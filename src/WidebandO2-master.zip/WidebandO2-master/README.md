WidebandO2
==========

An Arduino sketch for controlling a Bosch LSU 4.9 Wideband Lambda sensor with minimal parts

My current circuit is based off the Teensy++ 2.0 (AT90USB based), but have plans to port it to something more Arduino-y sometime in the future with adjustable pinouts.

Required Libraries
------------------

* RunningAverage - http://playground.arduino.cc/Main/RunningAverage
* PIDLibrary - http://playground.arduino.cc/Code/PIDLibrary

